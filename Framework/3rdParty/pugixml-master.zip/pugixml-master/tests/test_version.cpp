#include "../src/pugixml.hpp"

#if PUGIXML_VERSION != 170
#error Unexpected pugixml version
#endif
